@extends('layouts.app')

@section('body_class', 'agenda-viewport')

@section('css_data')
    <link href="{{ \App\Support\Scheduling\AgendaAssets::url('assets/vendor/fullcalendar/css/main.min.css') }}" rel="stylesheet">
    <link href="{{ \App\Support\Scheduling\AgendaAssets::url('css/scheduling/agenda.css') }}" rel="stylesheet">
    <link href="{{ \App\Support\Scheduling\AgendaAssets::url('css/scheduling/agenda-layout.css') }}" rel="stylesheet">
@endsection

@section('body')
    @include('templates.preloader')

    {{-- Usa el modo compacto que el shell ya trae; no modifica el layout de otros módulos. --}}
    <div id="main-wrapper" class="menu-toggle agenda-shell-compact">
        @include('templates.nav-header')
        @include('templates.chat-box')
        @include('templates.header')
        @include('templates.sidebar')

        <div class="content-body agenda-page">
            <div class="container-fluid agenda-page__container">
                <main class="agenda-board agenda-board--day" id="agenda-board" data-ui-screen="agenda"
                    data-capacity-url="{{ route('scheduling.mvp.agenda.regular-capacity') }}"
                    data-registration-store="{{ route('scheduling.mvp.agenda.registrations') }}"
                    data-auto-owner="{{ $autoOwner ? auth()->id() : '' }}"
                    data-auto-owner-name="{{ $autoOwner ? auth()->user()->name : '' }}"
                    data-off-hours-store="{{ route('scheduling.mvp.agenda.appointments.off-hours') }}"
                    data-feed="{{ route('scheduling.mvp.agenda.feed') }}"
                    data-appointment-store="{{ route('scheduling.mvp.agenda.appointments.store') }}"
                    data-can-create-appointments="{{ $canCreateAppointments ? '1' : '0' }}"
                    data-can-workflow="{{ $canWorkflow ? '1' : '0' }}"
                    data-can-audit="{{ $canAudit ? '1' : '0' }}"
                    data-additional-store="{{ route('scheduling.mvp.agenda.appointments.additional') }}"
                    data-reschedule-url="{{ url('/scheduling-mvp/agenda/appointments') }}"
                    data-can-reschedule="{{ $canRescheduleAppointments ? '1' : '0' }}"
                    data-can-additional="{{ $canCreateAdditional ? '1' : '0' }}"
                    data-can-assign-responsible="{{ $canAssignResponsible ? '1' : '0' }}"
                    data-today="{{ $today }}"
                    data-grid-minutes="20">

                    <script type="application/json" id="agenda-doctor-services">@json($doctorServices)</script>

                    @include('scheduling.agenda.partials.toolbar')

                    <div class="agenda-workspace">
                        <aside class="agenda-operations" aria-label="Profesionales y calendario">
                            <div class="agenda-operations__pair">
                                @include('scheduling.agenda.partials.professionals')
                                @include('scheduling.agenda.partials.mini-calendar')
                            </div>
                        </aside>

                        <section data-ui-zone="grid" class="agenda-center" aria-labelledby="agenda-title">
                            <div class="agenda-center__head">
                                <div>
                                    <h2 class="agenda-section-title" id="agenda-title">Agenda horaria</h2>
                                    @if(auth()->user()->hasRole('ADMINISTRADOR'))
                                        @if(auth()->user()->can(\App\Support\Scheduling\SchedulingCapability::VIEW_AUDIT))
                                            <a class="ml-2" href="{{ route('scheduling.mvp.agenda.reports.index') }}">Exportar para gerencia (CSV)</a>
                                        @endif
                                        <a href="{{ route('scheduling.mvp.agenda.heatmap') }}">Mapa de clics</a>
                                    @endif
                                    <p class="agenda-range" id="agenda-range-label" aria-live="polite"></p>
                                </div>

                                <dl class="agenda-kpis" aria-label="Resumen del periodo">
                                    <div>
                                        <dt>Libres</dt>
                                        <dd id="agenda-total-free">—</dd>
                                    </div>
                                    <div>
                                        <dt>Ocupadas</dt>
                                        <dd id="agenda-total-busy">—</dd>
                                    </div>
                                    <div>
                                        <dt>Min. libres <button type="button" class="agenda-help" data-help-title="Min. libres" data-help-text="Minutos todavía disponibles dentro del horario del profesional." aria-expanded="false" aria-controls="agenda-help-pop" aria-label="Ayuda: Min. libres">?</button></dt>
                                        <dd id="agenda-total-minutes">—</dd>
                                    </div>
                                    <div><dt>Especiales <button type="button" class="agenda-help" data-help-title="Especiales" data-help-text="Citas adicionales y atenciones fuera de horario." aria-expanded="false" aria-controls="agenda-help-pop" aria-label="Ayuda: Especiales">?</button></dt><dd id="agenda-total-special">—</dd></div>
                                </dl>
                            </div>

                            @include('scheduling.agenda.partials.context')

                            <div class="agenda-notice" id="agenda-load-state" role="status" aria-live="polite" hidden></div>

                            <section class="agenda-comparison" id="agenda-comparison" aria-labelledby="agenda-comparison-title" hidden>
                                <div class="agenda-comparison__head">
                                    <div>
                                        <h3 id="agenda-comparison-title">Comparación de profesionales</h3>
                                        <p>Resumen de carga para decidir qué agenda abrir. No comprime profesionales en la grilla horaria.</p>
                                    </div>
                                    <button type="button" class="agenda-btn" id="agenda-comparison-open">Abrir agenda seleccionada</button>
                                </div>
                                <div class="agenda-comparison__scroll">
                                    <table class="agenda-comparison__table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Profesional</th>
                                                <th scope="col">Especialidad</th>
                                                <th scope="col">Libres</th>
                                                <th scope="col">Ocupadas</th>
                                                <th scope="col">Min. libres</th>
                                                <th scope="col">Cobertura</th>
                                            </tr>
                                        </thead>
                                        <tbody id="agenda-comparison-body"></tbody>
                                    </table>
                                </div>
                            </section>

                            <div class="agenda-calendar-surface">
                                <section class="agenda-day-grid" id="agenda-day-grid"
                                    aria-label="Agenda operativa diaria">
                                    <div class="agenda-row-head" id="agenda-row-head" role="row"
                                        aria-label="Columnas de la agenda diaria">
                                        <span role="columnheader">Hora</span>
                                        <span role="columnheader">Citado</span>
                                        <span role="columnheader">Pago</span>
                                        <span role="columnheader">H.C.</span>
                                        <span role="columnheader">Apellidos y nombres</span>
                                    </div>

                                    <div class="agenda-day-grid__body" id="agenda-day-grid-body" role="rowgroup"></div>
                                </section>

                                <div id="agenda-calendar" class="agenda-calendar" hidden></div>
                            </div>

                            <div class="agenda-legend" aria-label="Leyenda de estados">
                                @foreach ($legend as $entry)
                                    <span class="agenda-legend__item">
                                        <span class="agenda-legend__marker"
                                            style="--key-color: {{ $entry['color'] }}; --key-bg: {{ $entry['fondo'] }}"
                                            aria-hidden="true"></span>
                                        <strong>{{ $entry['etiqueta'] }}</strong>
                                        @if (in_array($entry['clave'], ['PENDIENTE_CONFIRMACION', 'ADICIONAL', 'FUERA_HORARIO'], true))
                                            <button type="button" class="agenda-help" data-help-title="{{ $entry['etiqueta'] }}" data-help-text="{{ $entry['descripcion'] }}" aria-expanded="false" aria-controls="agenda-help-pop" aria-label="Ayuda: {{ $entry['etiqueta'] }}">?</button>
                                        @endif
                                    </span>
                                @endforeach
                            </div>
                            <p class="agenda-center__foot" id="agenda-detail-hint"></p>
                            <details id="agenda-withdrawal-history" hidden><summary>Retiros previos · horario liberado <span id="agenda-withdrawal-count"></span></summary><div id="agenda-withdrawal-history-list"></div></details>
                        </section>

                        <aside class="agenda-registration" aria-label="Registro y seguimiento de citas">
                            @include('scheduling.agenda.partials.quick-registration')
                            @include('scheduling.agenda.partials.withdrawal')
                            <details class="agenda-workflow"><summary>Reservas afectadas por cambios de horario <span id="agenda-contingency-badge"></span></summary><p id="agenda-contingency-status" class="agenda-action-notice" role="status" hidden></p><div id="agenda-contingency-list" aria-live="polite"></div></details>
                        </aside>
                    </div>

                    @include('scheduling.agenda.partials.patient-modal')
                </main>
            </div>
        </div>

        @include('templates.footer')
    </div>
@endsection

@section('script_data')
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('assets/vendor/global/global.min.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('assets/js/custom.min.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-shell.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('assets/js/deznav-init.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('assets/vendor/fullcalendar/js/main.min.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-selection.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-day-grid.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-week-event.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-week-background.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-week-slots.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/patients/patient-phone.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-patient-lookup.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-patient-draft.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-appointment-create.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-appointment-actions.js') }}"></script>
    @include('telemetry.collector', ['agendaAssetVersions' => true])
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-guidance.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-help.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-operational-form.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-form-validation.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('vendor/appointment-ocr/tesseract.min.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/appointment-receipt-ocr.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/appointment-receipt-review.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-operational-workspace.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-patient-navigation.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda-withdrawal.js') }}"></script>
    <script src="{{ \App\Support\Scheduling\AgendaAssets::url('js/scheduling/agenda.js') }}"></script>
@endsection
